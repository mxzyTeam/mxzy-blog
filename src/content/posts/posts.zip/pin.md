---
title: 加群向导
image: /random/h
published: 2025-05-24
pinned: true
category: 置顶
tags:
  - 联系
description: 关于如何联系二叉树树~
---


# 官方
## Telegram群组

[Telegram: Join Group Chat [2x.nz]](https://t.me/+_07DERp7k1ljYTc1)
## QQ群

> 为什么仅QQ群需要赞助？因为QQ作为国内平台，很容易被内鬼举报致使封群，但相对的，门槛更低，交流更方便。当然，如果您是高级用户，可以加入非QQ群。

请先 [赞助](/sponsors/) 至少 **10 CNY** 后加群。赞助时建议留备注，加群问题填写你留的备注或者交易订单号
点击链接加入群聊【2x.nz】： [QQ群](https://qm.qq.com/q/I2Quch1uy6)

![](../img/2b7baf19be5d905f546d196877248b5d.png)

# 非官方

> 粉丝自建

[Telegram: View @blog2x](https://t.me/blog2x)