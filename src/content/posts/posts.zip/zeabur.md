---
title: 想玩k3s？Zeabur来帮你！
published: 2025-09-03T06:49:16
description: 'Zeabur是一个PaaS服务，它可以让你将自己的服务器托管上去，然后在网页上进行管理，就像传统服务器面板一样，这些都是免费！'
image: '../img/8d1c016e47b686599365fbbece47d9f2.png'
tags: [k3s, Zeabur]

draft: false 
lang: ''
---

# 这是个啥？

它可以连接你的VPS（前提，CPU≥1c，RAM≥2G）。然后在你的机子上面跑服务，包括

![](../img/e24a92eb0b9b4e0a9221bad8f42257cb.png)

# 正式开始

进入 [My Servers - Zeabur](https://zeabur.com/servers)

点击创建

![](../img/5c196811af50670b8d2a31db0fb72d06.png)

点击添加自己的服务器

![](../img/1f75801da2752fd7329288ede20ac4aa.png)

阅读要求，继续

![](../img/9a495c0c92a9a28237f4abcb6d05d5a3.png)

填写SSH连接信息，让Zeabur连接到你的服务器

![](../img/cd045a83fa13d838043aaedc2c12781b.png)

之后会开始安装k3s等工具，我们将不再需要手动SSH登入服务器了，直接在Zeabur的网页上配置即可！

![](../img/a8ac2c06f087aa9aec6f2d69a6ce8241.png)

接下来我们可以尝试部署服务，Zeabur将服务部署到你自托管的服务器是不收费的

![](../img/c84dca61c169f71fea0d50e1097df600.png)

![](../img/7d261fad1dfe6fc67a4a39048add9f98.png)

请自由发挥！

![](../img/e24a92eb0b9b4e0a9221bad8f42257cb.png)
