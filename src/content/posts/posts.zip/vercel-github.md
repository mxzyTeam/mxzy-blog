---
title: 利用Vercel Function搭建一个Github全站反代
published: 2025-08-30T21:35:52
description: '嫌弃CF Worker不够快？那就试试Vercel Function！'
image: '../img/c0c8e9b43a1d504f817b2569663c6485.png'
tags: [Vercel]

draft: false 
lang: ''
---

# 正式开始

首先请阅读 [这篇文章](/posts/gh-proxy/) 知晓大致原理。

克隆 [afoim/VercelFunctionGithubProxy](https://github.com/afoim/VercelFunctionGithubProxy)，部署到Vercel，绑你自己域名

![](../img/515789171373802ea431301bd9379331.png)

![](../img/ceff1b9c347e67ad9a0cb09b33daf2bf.png)
