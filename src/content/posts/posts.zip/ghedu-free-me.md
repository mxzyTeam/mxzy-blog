---
title: wow！有GithubEdu资格？再嫖一个免费一年的.me域名！
published: 2025-08-11T22:37:55
description: '在群u的提醒下，发现除了.tech，还能再嫖一个米~'
image: '../img/d444bcf0be6d66d95ccd99fc39500772.png'
tags: [Github Edu]
category: '记录'
draft: false 
lang: ''
---

> 请先通过[这篇文章](/posts/github-edu/)拿到Github Edu~

前往 [GitHub 学生开发者包 - GitHub Education](https://education.github.com/pack)

往下滚直到找到这个

![](../img/8999f4a29c64d41041af3694812103cd.png)

点击这里

![](../img/c8d9061648114cd25e7b2fd05f98b81c.png)

进行Github授权

![](../img/d276c9dd0f20318008f448b1e5e64f5d.png)

成功验证学生资格咯~

![](../img/66be50cc3c5d65c3c72e2c303384d782.png)

选一个你喜欢的 .me 域名，然后加入购物车（FREE！）

![](../img/4e348f75335ecf233a417f5b636f23a0.png)

勾上Github Page，填上你的Github邮箱

![](../img/9fa66f48b438ec36e8b5374926be57ef.png)

接下来登录使用Github邮箱注册的号，没有号就注册一个！

![](../img/f2fc068c6365cc0ed39b1f2c9ce47372.png)

完成订单咯~

![](../img/08539178f0457e8d11e47c2a8ae6a0bb.png)

在控制台将NS转到Cloudflare！

![](../img/3c85f85d3a9acb8de98f0d719c643119.png)

![](../img/39f7a3295edfa45110d4218f0e3ca57e.png)

![](../img/e4d4f712ea9031e6d37f41ba1fdae47e.png)

NameCheap的NS传播似乎有些慢，等等咯~

半小时后有咯~

![](../img/5316225033dd82ce1afa3ecb032f6afb.png)
