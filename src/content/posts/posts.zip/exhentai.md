---
title: 手把手教你进入e站里站（exhentai.org）
published: 2025-08-12T19:10:40
description: '上周也是突然想到e站这个神奇的网站，但是2年的账号居然进不了里站，这里总结一些进里站的心路历程~'
image: '../img/a478a7a88fc884bcc179273a613ba8ae.png'
tags: [exhentai]
category: '记录'
draft: false 
lang: ''
---

# 前期准备

- 欧美家宽IP。可以前往 https://2x.nz/ak 买一个

![](../img/984b0db01ebc79ce1a7afffc5bcafa05.png)

# 正式开始

挂上你的美国家宽梯子

进入 [E-Hentai Forums](https://forums.e-hentai.org/)

点击 `Register` 

![](../img/bd97f3b7eacffded77c9af0264ee39b7.png)

注册邮箱使用 `gmail.com`

> exhentai能不能进是账号创建的时候就决定的！一定要让平台认为你是美国家宽用户！

注册完毕后等大约一周（我是 2025-08-03注册的，2025-08-12已经可以进了），期间想干什么就干什么

一周之后，使用 **浏览器的无痕模式+英语界面** 再次进入 [E-Hentai Forums](https://forums.e-hentai.org/) 登录

然后前往 https://exhentai.org/ 

不出意外，成功进来

![](../img/9941569e917a6e2f26e4ced2bf541b05.png)

接下来F12打开控制台

保存Ck以便日后登录（就无需那个傻逼美国家宽了）

![](../img/d82faf6bb0350f5ff6374ff663de3a4b.png)
