---
category: 记录
description: 起因只是凌晨苏醒的灵机一动，然后...
draft: false
image: ../img/265c0437c3b73dce08e1c185421ead45.webp
lang: ''
published: 2025-04-04
tags:
- 生活
title: 卧室布局整改记录
---
# 前言

我的卧室曾经是这样的，如你所见，非常杂乱且布线乱七八糟

![](../img/cbb33a838f35a1931942b00c84f5112b.webp)

# 契机

今天早上起来我灵机一动，想着要不要整理一下，于是变成了

![](../img/4191d6a70cfd53c6e194892e306bf9ed.webp)

结束咯~