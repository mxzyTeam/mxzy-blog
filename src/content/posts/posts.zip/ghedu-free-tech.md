---
title: 有Github Education？来嫖一年免费的.tech域名！
published: 2025-08-11T21:45:08
description: '昨天也是成功通过了Github Edu验证，发现可以白嫖一年免费的.tech域名！'
image: '../img/5c07af0b6154c553cbfc3a9f4ced5fcc.png'
tags: [Github Edu]
category: '记录'
draft: false 
lang: ''
---

# 正式开始

> 请先通过[这篇文章](/posts/github-edu/)拿到Github Edu~

然后前往 [GitHub Student Developer Pack - GitHub Education](https://education.github.com/pack)

一直往下滚，直到找到 .tech 字样的项目，点击蓝色链接进入

![](../img/e779f31089ec06822eb096f5986d860e.png)

输入域名，然后添加到购物车

![](../img/c91d8cff79347a498579fd662b267773.png)

点击结账

![](../img/4a236fbca2b9c1db44c0e08fb6c4fd07.png)

在这里登录Github账户（我已经免费拿一个了所以拿不了噜~）

![](../img/8e6ceab774e563ee9a78735e6b38965c.png)

不出意外你的Total应该是0，点击就购买成功！

---

接下来来到 https://controlpanel.tech/

登录你的账户

输入你的域名并跳转到控制台

![](../img/6dd3fd7c564f6ba2c773a414b8f74840.png)

改NS到Cloudflare~

![](../img/f5599ab6f44904224026e738674bf6ee.png)

当当当当~ 

激活咯~

![](../img/5cdf81557a95e055795c66b3cb5afe5e.png)
