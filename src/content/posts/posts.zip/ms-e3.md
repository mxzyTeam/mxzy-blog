---
title: 永久免费OneDrive 5T，MS 365 E3保姆级拿下教程！
published: 2025-11-14T14:09:41
description: 曾经免费拿E5，但是封车很久了，现在E3又来了，快上车！
image: ../img/bf25f518108c1078b36a1baaad585cf1.png
tags:
  - 微软
  - OneDrive
draft: false
lang: ""
---
# 参考文献
[微软Office365 E3订阅回归？25个E3 Dev免费开通指南 - 极圈 奶昔论坛](https://forum.naixi.net/thread-6702-1-1.html)

[垃圾Dev！Office E3 Symphony可以订阅200万个授权许可 - 极圈 奶昔论坛](https://forum.naixi.net/forum.php?mod=viewthread&tid=6723)

> 注： 不建议碰Symphony

# 正式开始
注册一个全局管理员，一路下一步，到绑卡那里直接退出然后用你的 `xxx@xxx.onmicrosoft.com` 去登录就行，纳税人识别号随便填（认认真真写，地址精确到你区县就好了，国家一定要填CN，不然后面没办法走支付宝） https://signup.microsoft.com/get-started/signup?products=35dffc92-9eb4-4d5c-82c2-2582b37bb9c4&culture=zh-cn&country=cn 

买 E3（选择支付宝即可） https://admin.cloud.microsoft/?pid=C69E7747-2566-4897-8CBA-B998ED3BAB88&quan=25&bc=1&sku=189a915c-fe4f-4ffa-bde4-85b9628d07a0&ru=PDP#/Purchase/checkout

进 微软365管理中心 [主页 - Microsoft 365 admin center](https://admin.cloud.microsoft/#/homepage)

点击 账单 - 你的产品
![](../img/ef7ab666f118fb9014eb66536cd4cf53.png)

点分配许可证
![](../img/33b0337aa2d7e5ca71ac37cb2950956d.png)

分配给你主账户
![](../img/a38931c5ff06138ef7fe3f842f7f7a85.png)

你已经可以用1T OneDrive了，进入 [My Apps](https://myapplications.microsoft.com/) 选择OneDrive（如果进不去，或者根本没有OneDrive应用，可以直接使用 `https://你的组织名-my.sharepoint.com/my` 尝试访问，记得开梯子）
![](../img/fc35a3ae6a962970faefab864756d15b.png)

接下来我们来扩容

在管理中心点击全部显示
![](../img/568fcbbdf4e3c09ef32a6c56a71b0324.png)

选择 SharePoint
![](../img/6def0330752f75833def6d450e70abb0.png)

更改 设置 - OneDrive - 存储限制 为 5120 GB
![](../img/af7cf0445772699c994d8064801f2265.png)

此时等等你的账号就会同步扩容了，如果等不及我们可以来手动强制扩容

回到 管理中心 选择 用户-活跃用户-管理角色-OneDrive，强制扩容
![](../img/4ac8da4f55c7484ae4ac76613a7f45dc.png)
![](../img/d959bb7e9a1f7dd7ef777cea221f5b0b.png)

用刚才讲过的方法进入OneDrive，成功扩容
![](../img/9305513740c0b8d88490e45661b06650.png)

最后，注意一下，及时前往 [My Sign-Ins | Security Info | Microsoft.com](https://mysignins.microsoft.com/security-info) 绑定更多的安全信息，避免日后无法访问账号
![](../img/ba8158af4140eae2deac0121e1077246.png)