---
title: Github新版学生认证怎么过？用记事本！
published: 2025-08-08
description: '突然被粉丝怂恿来弄Github学生认证，弄了半天，被我发现了奇技淫巧？？？'
image: '../img/19426f8bc0302c86bbb4101d5a8fff44.png'
tags: [Github]
category: '教程'
draft: false 
lang: ''
---

# 正式开始

> 视频： https://www.bilibili.com/video/BV1kAtrzzEkG

确保你是个学生

并且拥有 **学生证、录取通知书、毕业证** 中的其中一种（我使用录取通知书）

首先来到 [Payment Information](https://github.com/settings/billing/payment_information) 确保是你的真实信息，并且姓名使用拼音

如果不是，请进行更改，然后**一定要重登Github！**

![](../img/eddc6ebe82b48e9b09fafafea7b47585.png)

接下来前往 [GitHub · Where software is built](https://github.com/settings/education/benefits) 推荐使用校园网或者流量

![](../img/f59dee339f399606b0922ef46d3e5b91.png)

按需选

![](../img/816c1df7828d29e656b51b4e7fdb09ee.png)

这里拍照注意！如果你的证件没有英文版的，请不要直接拍原件

找个记事本手动翻译一下

比如我的录取通知书翻译为

然后用手机拍照即可

![](../img/28ebecc6fef7afa51c80aa0a5f042713.png)

不出意外，批准！

![](../img/bd551bd0ec63fb8f33842a1d0cdd4584.png)

# 疑难解答

报错什么姓名不符，确保你的Github Payment Information姓名和你提交的证明文件姓名一样，如果不一样，改完一定要注销重新登录Github才行
报错用了VPN或者位置不对，请确保使用中国大陆网络！如果你没有校园网就用流量！
