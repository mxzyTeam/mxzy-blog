---
title: 你说什么？企业微信能免费用Deepseek？！还能调成猫娘？！！
published: 2025-08-07
description: '今天无意中建了个企业微信群，然后就发现可以加智能体，然后就调了个猫娘出来...'
image: '../img/b19374dfec4b23337985eea1bf0364d0.png'
tags: [企业微信, Deepseek]
category: '记录'
draft: false 
lang: ''
---

# 正式开始

非常简单，首先你要有一个企业微信号

然后前往 `工作台` 往下拉找到 `智能机器人` 

![](../img/6c9f1ce271ea1da501166a42c8fbecbd.jpg)

接下来就可以创建了

在 `角色设定` 可以提示词注入一下

![](../img/523326d232f37b178fa62f3c5e1fa816.jpg)

然后你就得到了

![](../img/c7954357be70c14e019be9d2bd3a7151.jpg)

可以通过多种方式使用~

![](../img/d82ed7bcacbfb08a9aaa6c137eaf1885.jpg)
