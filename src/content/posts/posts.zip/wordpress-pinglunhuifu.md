---
title: 简洁的wordpress评论回复插件示例
published: 2025-08-21
description: 'Wordpress回复插件'
image: '../img/594ddaf873e1fa385a3a2ef3f0cf2516.png'
tags: [wordpress]
category: '记录'
draft: false 
lang: ''
---

> 本文由 https://github.com/afoim/fuwari/pull/40 提供，非站长原创

[https://github.com/yunsen2025/wordpress-pinglunhuifu](https://github.com/yunsen2025/wordpress-pinglunhuifu)
# 效果演示
![alt text](../img/594ddaf873e1fa385a3a2ef3f0cf2516.png)
# 关于代码
[https://www.yunsen2025.top/007-wp-ping-lun-hui-fu-cha-jian/](https://www.yunsen2025.top/007-wp-ping-lun-hui-fu-cha-jian/)   
必应搜的优化了一下，不满意的可以自由更换插件中的邮件html内容  
# 使用方法
直接下载php打包zip去wp后台上传或把代码粘贴到functions.php（主题一更新就没了）  
# 赞助
[前往](https://www.yunsen2025.top/support/)
