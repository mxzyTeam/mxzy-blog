---
category: 教程
description: 使用R2存储图片，通过Workers连接，最后使用a标签或img标签在网页中嵌入展示，全链路上云
draft: false
image: ../img/65214c3b70c0d5d04acb655098e92ab9.webp
lang: ''
published: 2025-03-05
tags:
- Cloudflare R2
- Cloudflare Workers
title: Cloudflare R2+Workers！马上搭建自己的云上图床！
---
### **结果图**

![QmVgqgoC7G8NLS21WvR8j9gf5amu33XvuV68ZrgM5B9iFf.webp](../img/ab8ef86c1e504b6075c34e615d3cd647.webp)

### **原理**

图源由 Cloudflare R2 托管，通过两个 Workers 连接 R2 以展示随机横屏/竖屏图片，静态页面引用 Workers 的 URL 以实现以上界面

### **创建 Cloudflare R2 存储桶**

R2 实际上是一个对象存储。Cloudflare 提供 10G 的免费存储和每月 1000 万次的免费访问

1. 进入[Cloudflare 仪表盘](https://dash.cloudflare.com/)，进入 R2 页面，如图
   
   ![QmU7u2JHUcevyHnwsCdAZfs7X7Fcdh3KJhn6eoy24Q5dGC.webp](../img/fb24336ea699f545563ed0b10a090b7e.webp)

2. 选择创建存储桶![QmX3eCaCVEgE8AN29D9t2VpQ5t5SrZGKb8EcZv9oKpCqf2.webp](../img/eeec09e9c2311c716d69e6c5bb43d6ca.webp)

3. 为你的存储桶起一个名字，然后单击创建![QmVad5eoJCLpSNZ4HCvTPJfD8rpg4aePMzZ7j2DZATn1XD.webp](../img/1cd7d46fa65fab030332fd1e366f59e9.webp)

4. 进入如下页面就已经创建完毕了![QmSdzwBJpw2L4a8LJ3eM3VMJs3d5oV5iFCxCMtv69VZmYH.webp](../img/12586ed23d75f73bf472af99e15793b3.webp)

5. 返回 R2 首页。因为在下文我们需要使用 API 来进行文件传输，所以需要创建你的 R2 API 令牌，单击管理 R2 API 令牌![QmbS8zjJTESwsmycKBSC9kmabAA9dtSCUX8nbUDWg4BWRX.webp](../img/3df921ac4fb0352bb267b79e45b9e836.webp)

6. 单击创建 API 令牌，如图![QmPzJEHVAm4z3S1SHY4k99TugrPyTB9DXpyRR8Loj22bz3.webp](../img/9ec1b3a1150b168e3a9af948ba388192.webp)

7. 因为我们需要该 API 来管理单个 R2 存储桶，所以选择**对象读和写**，详细配置如图![QmNY9p8hksi18B9R8TVfdGgu336oQ3cPmghyfYXE9CDGD4.webp](../img/9e5183b14cd47c274164c9c9c4129df4.webp)

8. 创建 API 令牌后，新页面会展示令牌的详细信息，**仅会展示一次！！！** 保持这个页面，直到你将该页面的所有信息都已经妥善保存，不要关闭界面，否则，你需要轮转 API 令牌以禁用之前的旧密钥，如图![QmZTUwbycqbJhVP6PatD3psYy7ej9PDDoiXbmDWoakPhwx.webp](../img/d7606410a3ea0384ceb4ee7eeaf8324f.webp)

9. 确保你已经妥善保存你的 R2 API 令牌，然后进行下一步

### **为你的存储桶添加文件**

因为 Web 界面传输文件较慢且不支持传输大于 300MB 的文件。这里使用本地部署 AList 然后连接你的 R2 存储桶实现高速上传

1. 笔者使用 Windows。前往[AList - Github Release](https://github.com/alist-org/alist/releases)下载适用于 Windows 的最新可执行文件，如图![QmPDRDJGeGStreyZMXVYofbE9FCs1T1MyDek3KUbB3Kk5b.webp](../img/54115d2c329dd67cfd71885a2524c2ba.webp)

2. 将下载的压缩包解压，并将其中的`alist.exe`放入一个空文件夹

3. 单击搜索框，输入 cmd 并回车，如图

4. ![QmSt8aFtaeEprJHASEiNPB67UHcHoSxsbhhHUPxW6QkWSo.webp](../img/ac9c9533ce0d29c4aa1f22d157c3b4da.webp)
   
   ![QmNkMhDhpPLkYCpVhE1ov7Q6A34uWDvraCqNvuTqaCkujT.webp](../img/30911beff312a024f1d57b788ee93536.webp)
   
   在 cmd 中输入`alist.exe server`并且不要关闭窗口，运行成功后如图![QmdzyY8xbic8jdnZEXegefoZPeizqHa4ZkdMnRKoguBMkf.webp](../img/5ce9fe240a38e0738608eb3bddd7d4bd.webp)

5. 打开浏览器，输入`localhost:5244`即可进入 AList 控制台，如图![QmUBFKu7mCiRneCrsTNPxTH6S4gxwtXf9cwLzf4dKW9LLR.webp](../img/f4a6a5cfef761652501110ec846aed41.webp)

6. 用户名：`admin`密码：`在cmd窗口中，如图`。你可以使用鼠标左键在终端中框选内容然后单击鼠标右键进行复制操作![QmVH3qZYo3QE6anNHymwkikq5MSeJphrZNR7RCH5jpP3wn.webp](../img/4488a84b497810d9e61051503be0b9d8.webp)

7. 注意，在 cmd 中，鼠标左键点击或拖动 cmd 的终端界面会导致进入选择状态，程序将会被系统阻塞，**需要在终端界面点按鼠标右键解除**。若进程被阻塞，cmd 的进程名会多一个**选择**，请注意。如图是程序被阻塞的例子，**在终端界面点按鼠标右键即可解除**
   ![QmapESiqSEvbYq3AJs15yYvhemRxSHrJaccjTFr99muX6Z.webp](../img/6c19398e3ad0b616e032710ae7a1935a.webp)

8. 现在，你已经成功以管理员身份登入了 AList单击最下面的**管理**![QmfNE53GThdjVrh4q64MJcZqwcGPD7UtcYTNw9bVBaSEaF.webp](../img/85346c18ee233a380a52af6d1763432f.webp)

9. 你会进入到如图界面。尽管 AList 运行在本地，也建议更改你的用户名和密码![QmNdD8UU8fkVDBz5dXdJhCF2fZg8P1FwrcMaaTsG6a7ENy.webp](../img/56766f6d80e0fd8a9e217f8a2c517656.webp)

10. 更改账密，重新以新账密登录![Qmas7pMiPR2FNTXheBT1xGNUpzDiSzv7J7yd6oCuT17yad.webp](../img/faaf8b91c4f02ccf4c44685e03386a6e.webp)

11. 进入控制台，然后单击存储，如图![QmS4gGyCM1j3RXgHEPuZ1zTbLAvGtVBEiPXJe9QMF3dD2D.webp](../img/81bdfff4e8a2afdfb95bf7d3c80229de.webp)

12. 选择添加，如图![QmRDVxt8WbrVkHavgFNXj3qC86ysw6sSZhPy3Uf2ixKp2E.webp](../img/df727540a560f91855c489b5c0a21eb1.webp)

13. 详细配置如图。挂载路径即 AList 展示路径，推荐使用`/R2/你的存储桶名字`，地区为`auto`![](../img/14f5b4681b060aac64f224bca17de4b2.webp)回到主页，如图![QmSnR9Ptrssx4nqk9qCvhFUNKQyQqJiN7GRscwoj4Dczgj.webp](../img/41571f4a7f06a89b78e5d4fe260889d1.webp)

14. 尝试上传文件，如图![QmPqFsmZNNnh4jNyLS7X3h8Zr6ZCVqTqGVwTxmPDdbmrGW.webp](../img/91075044033b7802e454562c803cbdac.webp)

15. 可以看到，速度非常快![QmXfGK6aZjz741GrY8RfFfKMkUzDMB3xhx93PGZ9S1QycT.webp](../img/18eb22d7aa9fc7da313a96a084b4c1ae.webp)

16. 为你的图床创建目录以分类横屏和竖屏图等，以便下文使用 Workers 连接 R2 来调用。后文我将使用R2的`/ri/h` 路径作为横屏随机图目录、`/ri/v` 路径作为竖屏随机图目录

![QmNdD8UU8fkVDBz5dXdJhCF2fZg8P1FwrcMaaTsG6a7ENy.webp](../img/56766f6d80e0fd8a9e217f8a2c517656.webp)

### **创建 Workers，连接 R2**

1. 进入[Cloudflare 仪表盘](https://dash.cloudflare.com/)，进入 Workers 和 Pages 页面，如图![QmW5UaUap8T2R37u5dzmKGLmUgk4qKnSMFwHBVHqvVbkVA.webp](../img/3dae72cae85533d3ce487750d7571d6c.webp)

2. 单击创建，选择创建 Workers，名称自取，单击部署![QmVvLv5n41QQfDfYiVWYRpsfw7TVNGy1BYuv5e8vBRhKLA.webp](../img/765c9e97222ac0c18f064cbd10e98206.webp)

3. 选择编辑代码![QmTbRifzXQ593DGyjFQMbA9exyNp2iAeAg4zbVrfFimQc4.webp](../img/16fba709388804986153f7395827200b.webp)

4. 粘贴代码（创建随机横屏图）：

新代码：

```
export default {
  async fetch(request, env, ctx) {
    const bucket = env.MY_BUCKET;
    const url = new URL(request.url);
    const hostname = url.hostname;

    // 初始化prefix
    let prefix = '';
    
    // 根据域名判断prefix
    if (hostname === 'hpic.072103.xyz' || hostname === 'api-hpic.072103.xyz') {
      prefix = 'ri/h/';
    } else if (hostname === 'vpic.072103.xyz' || hostname === 'api-vpic.072103.xyz') {
      prefix = 'ri/v/';
    } else {
      return new Response('Invalid domain', { status: 400 });
    }

    try {
      // 如果是API域名，只返回数量
      if (hostname.startsWith('api-')) {
        const objects = await bucket.list({ prefix: prefix });
        const count = objects.objects.length;
        const headers = new Headers({
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'text/plain'
        });
        return new Response(count.toString(), { headers });
      }

      // 原有的随机图片逻辑
      const objects = await bucket.list({ prefix: prefix });
      const items = objects.objects;
      
      if (items.length === 0) {
        return new Response('No images found', { status: 404 });
      }
      
      const randomItem = items[Math.floor(Math.random() * items.length)];
      const object = await bucket.get(randomItem.key);

      if (!object) {
        return new Response('Image not found', { status: 404 });
      }

      const headers = new Headers();
      headers.set('Content-Type', object.httpMetadata.contentType || 'image/jpeg');

      return new Response(object.body, { headers });
    } catch (error) {
      console.error('Error:', error);
      return new Response('Internal Server Error', { status: 500 });
    }
  },
};
```

旧代码：

```
export default {
  async fetch(request, env, ctx) {
    // R2 bucket 配置
    const bucket = env.MY_BUCKET;

    try {
      // 列出 /ri/h 目录下的所有对象
      const objects = await bucket.list({ prefix: 'ri/h/' });

      // 从列表中随机选择一个对象
      const items = objects.objects;
      if (items.length === 0) {
        return new Response('No images found', { status: 404 });
      }
      const randomItem = items[Math.floor(Math.random() * items.length)];

      // 获取选中对象
      const object = await bucket.get(randomItem.key);

      if (!object) {
        return new Response('Image not found', { status: 404 });
      }

      // 设置适当的 Content-Type
      const headers = new Headers();
      headers.set('Content-Type', object.httpMetadata.contentType || 'image/jpeg');

      // 返回图片内容
      return new Response(object.body, { headers });
    } catch (error) {
      console.error('Error:', error);
      return new Response('Internal Server Error', { status: 500 });
    }
  },
};
```

5. 点击左侧的文件图标![QmQGQTiTXSESU2TSJ6tc3KrzWU4KABKqn6QZ1GdWqKnWmc.webp](../img/c13584250041c04ee8b67ec9a5e60ce4.webp)

6. 在`wrangler.toml`中填入：

```
[[r2_buckets]]
binding = "MY_BUCKET"
bucket_name = "114514"
```

7. 保存修改，点击右上角的部署![QmP7hXdtenrJrzJRRePHQATGtyAsZEr5MkMsboXvmNUxTx.webp](../img/c422388bc329aa2d7187cec8c13b0b70.webp)

8. 在设置 - 变量找到 R2 存储桶绑定，添加你的存储桶，变量名即上文的`MY_BUCKET`![QmStitSyATnA8sY9tTgZaXXqmqkGPUtZmMxn9KjbFQzgTc.webp](../img/6438fb3de0a2a66fccf00532f5e43e52.webp)

9. 在设置 - 触发器添加你的自定义域名以便访问![QmUMxtkCiKsgFw8afRUGREFztXE9D5W6FmCbAUB7DaVH5o.webp](../img/21c6a3f5688210417815c49a9d210efb.webp)
   
   ![QmPF9iCoq6n8Jj2Z6kPkdJSCm45VJystZoYcir55yceCQo.webp](../img/feab68604949242e0e520a527d0105b1.webp)

10. 访问效果，每次刷新都不一样![QmQgEdjXxF9oph2jYKzFMJToX9WfG11jUmPiNJnjhYVN4N.webp](../img/38f0fdc8ed16aa3bcc8a428c1d2fa149.webp)

### **通过使用 HTML 的 `<img>` 标签引用即可达到开头的效果**

如：`<img src="你的域名" alt="">`
<img title="" src="https://hpic.072103.xyz" alt="loading-ag-4760">
