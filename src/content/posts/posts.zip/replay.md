---
category: 教程
description: Replay是一个自动化的AI翻唱软件，用户仅需要提供想要翻唱的歌和RVC模型，Replay会自动进行人声分离，并生成AI翻唱音频，对于新手来说十分友好
draft: false
image: ../img/71a992486a66e7a6d5c7b6226ab382b0.webp
lang: ''
published: 2024-10-15
tags:
- Replay
title: 傻瓜式AI翻唱软件Replay！选歌！选模型！然后CREATE SONG！
---
### AI翻唱！仅需两步！

1. 前往[Replay | Free AI Voice Cloning and Stemming using RVC Models (tryreplay.io)](https://www.tryreplay.io/)下载Replay

2. 打开Replay，首先根据引导下载数据包（约11G）。然后根据图片操作，选择歌曲和模型，最后点击 `CREATE SONG` 即可！![](../img/3bebc44414c9f44eb18406379536c787.webp)![](../img/ca62c7f957850885d230d76438303da2.webp)
