---
category: 随笔
description: Rewrite打完才发现MV一个没看到
draft: false
image: https://eo-r2.2x.nz/myblog/img/bafybeihhyuk3zjqkisf66swxft4j5srv3g7wozy3zn4ykpsh3cuveuuwb4.png
lang: ''
published: 2024-11-28
tags:
- Rewrite
title: 关于Rewrite MV无法播放\没有画面的解决方法
---
# 我使用的解决方法（Windows 10及以上带有Microsoft Store的系统）

安装这个即可

![image](https://eo-r2.2x.nz/myblog/img/bafkreieb2qknggudxx7sc723jheso6grhgemznjqb5n6yqwsrvgqkqn4ba.png)

然后游戏内改为Windows Media Player

![image](https://eo-r2.2x.nz/myblog/img/bafkreihujn3jctibvixv4trpsu5j4d2v7de2ibzea6xe6pzmithymffpqu.png)

# 汉化组提供的解决方法

安装：[K-Lite Basic解码器](https://www.codecguide.com/download_k-lite_codec_pack_basic.htm)

然后游戏内改为 MCI

![image](https://eo-r2.2x.nz/myblog/img/bafkreic7a3tnnoxyn646tzy35nec2oioz4ktffuizb5ge67ibww5ntnmpq.png)
