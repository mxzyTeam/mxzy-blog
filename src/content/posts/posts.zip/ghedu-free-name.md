---
title: 我去！GithubEdu还能再再再嫖俩免费一年域名？！
published: 2025-08-11T23:04:10
description: '也是依旧在群u的帮助下又捞了俩米！'
image: '../img/6afbe75f0c133146cdd44e74dba5fb51.png'
tags: [Github Edu]
category: '记录'
draft: false 
lang: ''
---

# 正式开始

前往 [GitHub 学生开发者包 - GitHub Education](https://education.github.com/pack)

往下滚动 找到

![](../img/15405a911bd7e19acd533e87a4ebcc69.png)

点击登录并验证你的学生身份

![](../img/0e8fa77432dad00f5fa7b0c382ad5a16.png)

短域名也有免费的！

![](../img/f9d6b40e2a22f255822543ab9593d1fc.png)

长域名更是不在话下！

![](../img/1971d7fcbf798c99c0d8c59af748a1f5.png)

但是最终结账的时候只能免费**两个**域名哦~

![](../img/37a0673fe27117e851fab32d8b7a97d0.png)

需要绑卡验证，扣0.00元。Bybit虚拟卡可用

![](../img/9f988ef50b2c074793bfbeaf113236fb.png)

![](../img/d0b88417365ce903f81d484e4a1aabe3.jpg)

等待跑进度条~

![](../img/bf648179353b36d7af42bc9a8b4a00df.png)

接下来老生常谈的改NS到Cloudflare

![](../img/ab62c27ed26c9dd9f43f3fb9664654db.png)

![](../img/fbf83cb3f46ec0d27195ce7520ba350d.png)

![](../img/a46a59e4cdfdbb530af8c5e6e3c1f030.png)

成功激活~

![](../img/af3c77e58d70e3dde53354e3776d054d.png)
