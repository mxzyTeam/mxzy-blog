---
title: Reality协议的代理服务端搭建教程
published: 2025-09-09
description: 'Reality协议是目前最抗检测的一种代理协议'
image: ../img/3cd5507b89aabd422d45df9ecbedcfd0.webp
tags: [Reality]
category: '教程'
draft: false 
lang: ''
---

# 正式开始

> 源码： [afoim/one-times-reality: 一行命令帮你装好reality](https://github.com/afoim/one-times-reality)

自己看README部署
