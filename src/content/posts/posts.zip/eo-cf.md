---
title: EdgeOne + Cloudflare，我们天下无敌！
published: 2025-06-27
description: 'EdgeOne的低延迟+Cloudflare的强大业务！我都不敢想这有多爽！'
image: ../img/ea19bd8797c6b38c38f9d14843a8762c.webp
tags: [EdgeOne, Cloudflare]
category: '记录'
draft: false 
lang: ''
---

# 引言

主播也是搞到了EdgeOne免费版激活码了，终于可以大展宏图了😋

# 我怎么换到EdgeOne免费版？

前往 [腾讯云EdgeOne免费计划兑换码 - 立即体验](https://edgeone.ai/zh/redemption)

推荐直接发推，按照要求发

发完后私信EO官方即可

![](../img/835c311918f9d5887aa180909be09f5c.webp)

# 默认EdgeOne给的Anycast CNAME过于垃圾？

默认在EO添加域名EO会发给你一个类似 `afo.im.eo.dnse4.com` 这样的CNAME

也就是 `你的域名.eo.dnse4.com` 

emm 这玩意吧 你们自己看速度吧

![](../img/de0724ffd347f1ee0c77f0b6fa19c8d7.webp)

我推荐大家使用 `43.174.150.150` 。是一个中国香港的三网优化IP。速度如下。**本人EdgeOne优选：** `eo.072103.xyz`

![](../img/17c8ca6175ff25eae22d47652205ae15.webp)

# 换了CNAME后无法自动申请免费SSL？

如果你将你的域名托管给EO并且没有用EO给你的CNAME，则这个选项不可用

![](../img/c14605658e8a3756ae6587688847594e.webp)

我推荐采用1panel、宝塔、acme.sh手动申请泛域名证书然后上传到腾讯云SSL控制台，就像这样

![](../img/0a0096c8a9d13cefcf8f7cc3f7fca301.webp)

# EdgeOne怎么做重定向？

在这里

![](../img/5bd191af6223cebacc32809721cf7214.webp)

![](../img/70726ae5e2f5c05db0a07daa67b91b99.webp)

EO边缘函数也支持重定向，支持更细化的重定向规则

但是这玩意记录请求数，不如用Cloudflare的重定向规则

![](../img/9220289342f244deaf8336b2e63b352f.webp)

首先我们在CF写这样一个规则
![](../img/d7fd27fab78a4fc5f15bfb563a4fd397.webp)

然后让EO回源到CF边缘节点。最简单就是随便填个IP然后套CDN

![](../img/3c2dc4e4bcffa1e9fb0ffe695a8fe104.webp)

接着配置EO回源，这里一定要使用加速域名作为回源Host头

![](../img/87510b2db240583a6ed1cdf80ac5448f.webp)

原理：用户 - EO - CF - CF识别到Host匹配重定向规则 - 301

# EdgeOne反代一切？

> 大部分情况将 `回源HOST头` 改为源站就能解决反代后网站无法访问的问题
> 
> ![](../img/91025039db7c2f05972996c132250e7f.png)
