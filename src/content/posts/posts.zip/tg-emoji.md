---
title: 教你制作自己的Telegram Emoji！
published: 2025-08-11T21:22:46
description: '欧呦不赖，开了个大会员终于可以戴上Netlify的表情咯~'
image: '../img/62004407d33abc10cec7e56754869ad7.png'
tags: [Telegram]
category: '教程'
draft: false 
lang: ''
---

# 正式开始

> 本文讲述的是添加TG的Emoji，不是贴纸！！！

准备若干张 PNG或WEBP，100x100 px的图片

然后找到 @Stickers

发送 `/newemojipack` 

![](../img/84143f06f939ab5d76aa9236df581fec.png)

这里使用静态表情，即 `static` 

![](../img/0e752e9e2930f4e2456d5e69a9a1bcae.png)

接下来随便起个名字，我这里就叫 `Logo` 

然后发送你的图片

![](../img/5bda8065224b5e512dbe7ea10f645a97.png)

接下来发送一个能代表你表情的Emoji，并且发布

![](../img/537fda514b0b0083d0f43ba38560f96a.png)

然后设置一个 `pathname` 

![](../img/a1851b3af57d6085e32e58c01f413237.png)

点击上面的链接就可以添加咯~

如果你是Telegram Premium，还可以挂在昵称旁边哦~

![](../img/9d633c24030a53e4db14db97f5164e85.png)
